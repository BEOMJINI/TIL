package s0_Mall;

public class Mall {
	//private String loginId;
	
}
