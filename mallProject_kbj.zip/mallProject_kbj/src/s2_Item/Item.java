package s2_Item;

public class Item {
	private int num;
	private String categoryName;
	private String name;
	private	int price;
}
