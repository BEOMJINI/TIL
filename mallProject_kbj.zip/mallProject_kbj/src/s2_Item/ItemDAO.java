package s2_Item;

public class ItemDAO {

}
