package s_Util;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Util {

	public static Scanner sc = new Scanner(System.in);

	public static int getValue(int a, int b) {
		// Scanner sc = new Scanner(System.in);
		int val = -1;
		while (true) {
			try {
				System.out.print("# 선택 ->  ");
				val = sc.nextInt();
				if (val < a || val > b) {
					System.err.println(a + " ~ " + b + " 사이 값 입력");
					val = -1;
				}
			} catch (InputMismatchException e) {
				System.err.println("숫자값만 입력");
				sc.nextLine();
			}
			return val;
		}
	}
}
